# call the plot package
library(grid)
library(ggplot2)
library(reshape2)
library(akima)

# start to read data
# data are read in portion
setwd("D:/MAIZSIM_ROOT9.1/Ex_1_Three_Part/Ex1_Irrigation")
MyData=read.table("BARC05HN.G04",header=TRUE,sep=",",skip=12143,nrows=467)
colnames(MyData)=c("Date_time","Date","X","Y","Node","RMass","RMass","RDenM","RDenY","WaterSink","NitSink","GasSink","Area")

# rearrange the data
xx=MyData$X
yy=MyData$Y
zz=(MyData$RDenM+MyData$RDenY)

fld=with(MyData,interp(xx,yy,zz))
df=melt(fld$z,na.rm=FALSE)
names(df)= c("x", "y", "RootDen")
df$Hori=fld$x[df$x]
df$Vert=fld$y[df$y]-220
p=ggplot(data=df, aes(x=Hori, y=Vert, z=RootDen)) +
  geom_tile(aes(fill=RootDen)) +
  ggtitle("Root Length (cm)") +
  xlab("Horizontal Scale (cm)") +
  ylab("Soil Depth (cm)") +
  scale_fill_gradientn(name = "Root Length (cm)", colours = c('white','red','blue','black'))+
  geom_contour(aes(z=RootDen))+
  geom_text_contour(aes(z=RootDen), stroke = 0.2)+
  theme(plot.title = element_text(size = 25, face = "bold"),
        legend.title = element_text(size = 15),
        axis.text = element_text(size = 15),
        axis.title.x = element_text(size = 20, vjust = -0.5),
        axis.title.y = element_text(size = 20, vjust = 0.2),
        legend.text = element_text(size = 10))
p

zzSum=(MyData$RDenM+MyData$RDenY)*MyData$Area
SUmSum1=array(0,c(21,1))
YYSum=seq(21,1,-1)

for(k in YYSum)
{
  if(k==21)
  {
    zzSumLayer=zzSum[as.array(which(MyData$Y>=10*k & MyData$Y<=10*(k+1)))]
    SUmSum1[1]=sum(zzSumLayer)
  }
  zzSumLayer=zzSum[as.array(which(MyData$Y>=10*k & MyData$Y<10*(k+1)))]
  SUmSum1[22-k]=sum(zzSumLayer)
}


MyData=read.table("BARC05HN.G04",header=TRUE,sep=",",skip=26620,nrows=467)
colnames(MyData)=c("Date_time","Date","X","Y","Node","RMass","RMass","RDenM","RDenY","WaterSink","NitSink","GasSink","Area")

# rearrange the data
xx=MyData$X
yy=MyData$Y
zz=(MyData$RDenM+MyData$RDenY)

fld=with(MyData,interp(xx,yy,zz))
df=melt(fld$z,na.rm=FALSE)
names(df)= c("x", "y", "RootDen")
df$Hori=fld$x[df$x]
df$Vert=fld$y[df$y]-220
p=ggplot(data=df, aes(x=Hori, y=Vert, z=RootDen)) +
  geom_tile(aes(fill=RootDen)) +
  ggtitle("Root Length (cm)") +
  xlab("Horizontal Scale (cm)") +
  ylab("Soil Depth (cm)") +
  scale_fill_gradientn(name = "Root Length (cm)", colours = c('white','red','blue','black'))+
  geom_contour(aes(z=RootDen))+
  geom_text_contour(aes(z=RootDen), stroke = 0.2)+
  theme(plot.title = element_text(size = 25, face = "bold"),
        legend.title = element_text(size = 15),
        axis.text = element_text(size = 15),
        axis.title.x = element_text(size = 20, vjust = -0.5),
        axis.title.y = element_text(size = 20, vjust = 0.2),
        legend.text = element_text(size = 10))
p

zzSum=(MyData$RDenM+MyData$RDenY)*MyData$Area
SUmSum2=array(0,c(21,1))
YYSum=seq(21,1,-1)

for(k in YYSum)
{
  if(k==21)
  {
    zzSumLayer=zzSum[as.array(which(MyData$Y>=10*k & MyData$Y<=10*(k+1)))]
    SUmSum2[1]=sum(zzSumLayer)
  }
  zzSumLayer=zzSum[as.array(which(MyData$Y>=10*k & MyData$Y<10*(k+1)))]
  SUmSum2[22-k]=sum(zzSumLayer)
}



MyData=read.table("BARC05HN.G04",header=TRUE,sep=",",skip=42031,nrows=467)
colnames(MyData)=c("Date_time","Date","X","Y","Node","RMass","RMass","RDenM","RDenY","WaterSink","NitSink","GasSink","Area")

# rearrange the data
xx=MyData$X
yy=MyData$Y
zz=(MyData$RDenM+MyData$RDenY)

fld=with(MyData,interp(xx,yy,zz))
df=melt(fld$z,na.rm=FALSE)
names(df)= c("x", "y", "RootDen")
df$Hori=fld$x[df$x]
df$Vert=fld$y[df$y]-220
p=ggplot(data=df, aes(x=Hori, y=Vert, z=RootDen)) +
  geom_tile(aes(fill=RootDen)) +
  ggtitle("Root Length (cm)") +
  xlab("Horizontal Scale (cm)") +
  ylab("Soil Depth (cm)") +
  scale_fill_gradientn(name = "Root Length (cm)", colours = c('white','red','blue','black'))+
  geom_contour(aes(z=RootDen))+
  geom_text_contour(aes(z=RootDen), stroke = 0.2)+
  theme(plot.title = element_text(size = 25, face = "bold"),
        legend.title = element_text(size = 15),
        axis.text = element_text(size = 15),
        axis.title.x = element_text(size = 20, vjust = -0.5),
        axis.title.y = element_text(size = 20, vjust = 0.2),
        legend.text = element_text(size = 10))
p

zzSum=(MyData$RDenM+MyData$RDenY)*MyData$Area
SUmSum3=array(0,c(21,1))
YYSum=seq(21,1,-1)

for(k in YYSum)
{
  if(k==21)
  {
    zzSumLayer=zzSum[as.array(which(MyData$Y>=10*k & MyData$Y<=10*(k+1)))]
    SUmSum3[1]=sum(zzSumLayer)
  }
  zzSumLayer=zzSum[as.array(which(MyData$Y>=10*k & MyData$Y<10*(k+1)))]
  SUmSum3[22-k]=sum(zzSumLayer)
}

YYSumSum=c(YYSum,YYSum,YYSum)
SumSum=c(SUmSum1,SUmSum2,SUmSum3)root 
Group=c(rep('A',21),rep('B',21),rep('C',21))
RootLength=data.frame(YYSumSum,SumSum,Group)
q=ggplot(RootLength,aes(x=SumSum,y=YYSumSum,colour=Group,group=Group))+geom_path(size=2)+
  scale_y_continuous(breaks = round(seq(1,21, by=1),1))
q
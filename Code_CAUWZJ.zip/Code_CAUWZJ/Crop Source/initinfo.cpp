#include "stdafx.h"
#include "initinfo.h"

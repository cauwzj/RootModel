#include "stdafx.h"
#include "weather.h"
#include "StdAfx.h"
#include "ear.h"
//#using <mscorlib.dll>

CEar::CEar(void)
:COrgan(), totalKernels(0), seedWeight(0)
{
}

CEar::~CEar(void)
{
}
